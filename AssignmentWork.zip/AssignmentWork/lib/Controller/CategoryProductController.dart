import 'package:flutter_app/Model/Categories.dart';
import 'package:flutter_app/Services/CategoryService.dart';
import 'package:get/state_manager.dart';

class CategoryProductController extends GetxController {
  var isLoading = true.obs;
  var categoryProductList = List<Categories>().obs;

  @override
  void onInit() {
    fetchProducts();
    super.onInit();
  }

  void fetchProducts() async {
    try {
      isLoading(true);
      List categoryProduct = await CategoryServuice.fetchCategoryProducts();
      if (categoryProduct != null) {
        categoryProductList.value = categoryProduct;
      }
    } finally {
      isLoading(false);
    }
  }
}
