class ProductTax {
  String taxName;
  double taxValue;

  ProductTax({
    this.taxName,
    this.taxValue,
  });

  factory ProductTax.fromJson(Map<String, dynamic> json) {
    return ProductTax(
      taxName: json['name'],
      taxValue: json['value'] == null ? 0.0 : json['value'].toDouble(),
    );
  }

  Map<String, dynamic> toJson() => {
        "name": taxName == null ? null : taxName,
        "value": taxValue,
      };
}
