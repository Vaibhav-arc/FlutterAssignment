class RankingProduct {
  int rankingId;
  int rankingViewCount;
  int orderCount;
  int shares;

  RankingProduct(
      {this.rankingId, this.rankingViewCount, this.orderCount, this.shares});

  factory RankingProduct.fromJson(Map<String, dynamic> json) {
    return RankingProduct(
      rankingId: json['id'] as int,
      rankingViewCount: json['view_count'] as int,
      orderCount: json['order_count'] as int,
      shares: json['shares'] as int,
    );
  }
}
