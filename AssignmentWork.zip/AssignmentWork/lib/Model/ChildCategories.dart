class ChildCategory {
  int childCategoryNo1;
  int childCategoryNo2;

  ChildCategory({this.childCategoryNo1, this.childCategoryNo2});

  factory ChildCategory.fromJson(Map<String, dynamic> json) {
    return ChildCategory(
      childCategoryNo1: json[' '],
      childCategoryNo2: json[' '],
    );
  }

  Map<String, dynamic> toJson() => {
        " ": childCategoryNo1,
        " ": childCategoryNo2,
      };
}
