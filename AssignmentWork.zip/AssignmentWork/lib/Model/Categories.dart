import 'package:flutter_app/Model/CategoryProductRank.dart';
import 'Products.dart';

class Categories {
  int categoryId;
  String categoryName;
  List<Products> products;
  List<int> childCategory;
  List<CategoryProductRank> categoryProductRank;

  Categories(
      {this.categoryId,
      this.categoryName,
      this.products,
      this.childCategory,
      this.categoryProductRank});

  factory Categories.fromJson(Map<String, dynamic> json) {
    return Categories(
      categoryId: json['id'],
      categoryName: json['name'],
      products: List<Products>.from(
          json["products"].map((x) => Products.fromJson(x))),
      childCategory: List<int>.from(json["child_categories"].map((x) => x)),
      categoryProductRank: json['rankings'] != null
          ? List<CategoryProductRank>.from(
              json["rankings"].map((x) => CategoryProductRank.fromJson(x)))
          : List<CategoryProductRank>(),
    );
  }
}
