class ProductVariants {
  int variantId;
  String color;
  int size;
  int price;

  ProductVariants({this.variantId, this.color, this.size, this.price});

  factory ProductVariants.fromJson(Map<String, dynamic> json) {
    return ProductVariants(
      variantId: json['id'],
      color: json['color'],
      size: json['size'],
      price: json['price'],
    );
  }
}
