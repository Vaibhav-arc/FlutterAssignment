import 'ProductTax.dart';
import 'ProductVariants.dart';

class Products {
  int productId;
  String productName;
  String productDate;
  List<ProductVariants> variants;
  ProductTax productTax;

  Products(
      {this.productId,
      this.productName,
      this.productDate,
      this.variants,
      this.productTax});

  factory Products.fromJson(Map<String, dynamic> json) {
    return Products(
      productId: json['id'],
      productName: json['name'],
      productDate: json['date_added'],
      variants: List<ProductVariants>.from(
          json["variants"].map((x) => ProductVariants.fromJson(x))).toList(),
      productTax: ProductTax.fromJson(json["tax"]),
    );
  }
}
