import 'RankingProducts.dart';

class CategoryProductRank {
  String ranking;
  List<RankingProduct> rankingProduct;

  CategoryProductRank({
    this.ranking,
    this.rankingProduct,
  });

  factory CategoryProductRank.fromJson(Map<String, dynamic> json) {
    return CategoryProductRank(
      ranking: json['ranking'],
      rankingProduct: List<RankingProduct>.from(
          json["products"].map((x) => RankingProduct.fromJson(x))).toList(),
    );
  }
}
