import 'dart:convert';

import 'package:flutter_app/Model/Categories.dart';
import 'package:http/http.dart' as http;

class CategoryServuice {
  static var client = http.Client();

  static Future<List<Categories>> fetchCategoryProducts() async {
    final response =
        await http.get('https://stark-spire-93433.herokuapp.com/json');
    if (response.statusCode == 200) {
      var jsonResponse = json.decode(response.body);
      var categoryList = jsonResponse["categories"] as List;
      List<Categories> list = categoryList
          .map<Categories>((json) => Categories.fromJson(json))
          .toList();
      print(list.first.products.first.productName);
      return list;
    } else {
      throw Exception('Unexpected error occured!');
    }
  }
}
